# Dev an Pester

In order to make sure that i can test all the software woith too much verbose information i have the following variables:

|Variable|Description|Effects|
|---|---|---|
|global:pester_enabled|enable pester tests||
|||searches `bolt.pester.json` instead of bolt.json config file|
|||disables stdout of bolt log|
